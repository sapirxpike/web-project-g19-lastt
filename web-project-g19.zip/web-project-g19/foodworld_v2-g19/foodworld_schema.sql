-- -------------------------------------------------------------
-- TablePlus 4.5.2(402)
--
-- https://tableplus.com/
--
-- Database: foodworld
-- Generation Time: 2022-02-20 22:29:12.3040
-- -------------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `first_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `customers_dishes`;
CREATE TABLE `customers_dishes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `dish_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dish_id` (`dish_id`),
  KEY `email` (`email`),
  CONSTRAINT `customers_dishes_ibfk_1` FOREIGN KEY (`dish_id`) REFERENCES `dishes` (`id`),
  CONSTRAINT `customers_dishes_ibfk_2` FOREIGN KEY (`email`) REFERENCES `customers` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `dishes`;
CREATE TABLE `dishes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `price` int NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `ingredients`;
CREATE TABLE `ingredients` (
  `recipe_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int DEFAULT NULL,
  PRIMARY KEY (`recipe_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`email`) REFERENCES `customers` (`email`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `card_number` varchar(255) NOT NULL,
  `cvv` int DEFAULT NULL,
  `expressiondate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`card_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `ranks`;
CREATE TABLE `ranks` (
  `degree` tinyint NOT NULL,
  `recommandation` text,
  `recipe_id` varchar(255) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  PRIMARY KEY (`customer_id`,`recipe_id`),
  KEY `fk_recipeid` (`recipe_id`),
  CONSTRAINT `fk_customerid` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`email`),
  CONSTRAINT `fk_recipeid` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`recipeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `recipes`;
CREATE TABLE `recipes` (
  `recipeid` varchar(255) NOT NULL,
  `recipename` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`recipeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `search`;
CREATE TABLE `search` (
  `ip` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `country` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ip`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `customers` (`first_name`, `address`, `email`, `phone`, `last_name`, `password`) VALUES
('sapir', '123', 'daniel@com', '054', 'levi', '123'),
('Tomer', NULL, 'tomer@gmail.com', NULL, 'Lotan', '123');

INSERT INTO `customers_dishes` (`id`, `email`, `dish_id`, `created_at`, `status`) VALUES
(14, 'daniel@com', 3, '2022-02-20 19:28:32', 'pending'),
(35, 'tomer@gmail.com', 2, '2022-02-20 20:28:27', 'delivered'),
(36, 'tomer@gmail.com', 3, '2022-02-20 20:28:28', 'pending'),
(37, 'tomer@gmail.com', 6, '2022-02-20 20:28:30', 'delivered');

INSERT INTO `dishes` (`id`, `name`, `price`, `image`) VALUES
(1, 'Tamarind-Honey Chicken Breasts', 30, 'honey_chicken_breast.jpeg'),
(2, 'Orange Tofu & Brown Rice', 15, 'orange_tofu.jpeg'),
(3, 'Crispy Skin Salmon', 18, 'Crispy_Salmon.jpeg'),
(4, 'Fried Egg & White Cheddar Burgers', 15, 'egg_cheddar_burger.jpeg'),
(5, 'Za’atar White Bean & Rice Bowls', 12, 'zattar_white_beans.jpeg'),
(6, 'Seared Chicken & Creamy Italian Dressing', 18, 'chicken_creamy_italian.jpeg');



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;