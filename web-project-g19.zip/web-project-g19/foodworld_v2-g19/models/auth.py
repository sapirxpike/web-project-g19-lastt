from utilities.db.db_manager import dbManager
from flask import session

class Auth:
    @staticmethod
    def login(email, password):
        # Check if user exists
        user = dbManager.fetch(f"SELECT * FROM customers WHERE email = '{email}' AND password = '{password}'")
        if user:
                return user
        return False
    
    @staticmethod
    def logout():
        session.clear()
        return True
    
    @staticmethod
    def register(email, password, first_name, last_name):
        # Check if user exists
        user = dbManager.fetch(f"SELECT * FROM customers WHERE email = '{email}'")
        if user:
            return False
        else:
            # Save user to database
            dbManager.commit(f"INSERT INTO customers (email, password, first_name, last_name) VALUES ('{email}', '{password}', '{first_name}', '{last_name}')")
            return True