from utilities.db.db_manager import dbManager

class Dishes:
    @staticmethod
    def get_dishes():
        # Get all dishes from database
        return dbManager.fetch("SELECT * FROM dishes")

    @staticmethod
    def get_user_dishes(email):
        user_dishes = dbManager.fetch(f"SELECT customers_dishes.id, name, price, image, status, created_at FROM dishes JOIN customers_dishes ON customers_dishes.dish_id = dishes.id AND customers_dishes.email = '{email}' ORDER BY created_at DESC")
        return user_dishes

    @staticmethod
    def update_user_dish(email, dish_id, status):
        # Update user dish order in database
        dbManager.commit(f"UPDATE customers_dishes SET status = '{status}' WHERE email = '{email}' AND id = '{dish_id}'")

    @staticmethod
    def create_user_dish(email, dish_id):
        # Save user dish order to database
        dbManager.commit(f"INSERT INTO customers_dishes (email, dish_id, status) VALUES ('{email}', '{dish_id}', 'pending')")

    @staticmethod
    def delete_user_dish(email, dish_id):
        # Delete user dish order from database
        dbManager.commit(f"DELETE FROM customers_dishes WHERE email = '{email}' AND id = '{dish_id}'")
