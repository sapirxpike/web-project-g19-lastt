function increaseTotalPrice(totalPrice, recipePrice) {
    var value = parseInt(document.getElementById(totalPrice).value, 10);
    let Price = recipePrice;
    Price = isNaN(Price) ? 0 : Price;
    document.getElementById(totalPrice).value = value + Price
}

function decreaseTotalPrice(totalPrice, recipePrice) {
    var value = parseInt(document.getElementById(totalPrice).value, 10);
    let Price = recipePrice;
    Price = isNaN(Price) ? 0 : Price;
    var newTotal = value - Price;
    if (newTotal <= 0)
        document.getElementById(totalPrice).value = 0;
    else
        document.getElementById(totalPrice).value = newTotal;
}

function orderGiftCard() {
    alert("Thank You");
}

function saveUserDish(id) {
    console.log("dish id: ", id);
    fetch(`/create_user_dish?dish_id=${id.toString()}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
    }).then(res => res.json()).then(data => {
        alert("Dish added to your cart");
        document.querySelector(`#cart-dot`).style.opacity = "1";
    });
}

function deleteUserDish(id) {
    console.log("dish id: ", id);
    fetch(`/delete_user_dish?dish_id=${id.toString()}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        },
    }).then(res => location.reload());
}

function updateUserDish(id, status) {
    console.log("dish id: ", id);
    fetch(`/update_user_dish?dish_id=${id.toString()}&status=${status}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
    }).then(res => location.reload());
}