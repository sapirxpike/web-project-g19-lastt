from flask import Blueprint, render_template, redirect, url_for, request, session, Flask, flash, jsonify
from flask_session import Session
from models.dishes import Dishes
from models.auth import Auth

###### App setup
app = Flask(__name__)
app.config.from_pyfile('settings.py')
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.route('/index', methods=['GET'])
@app.route('/')
def foodworld_homepage():
    print(session.get('logged_in'))
    if(session.get('logged_in')):
        return render_template('index.html')
    else:
        return redirect(url_for('login_Page'))

@app.route('/giftcard', methods=['GET'])
def get_dishes():
    if session.get('logged_in'):
            dishes = Dishes.get_dishes()
            return render_template('giftcard.html', dishes = dishes)
    else:
        return redirect("/login")

@app.route('/cart', methods=['GET'])
def get_user_dishes():
    if session.get('logged_in'):
        email = session.get('email')
        user_dishes = Dishes.get_user_dishes(email)
        return render_template('cart.html', dishes = user_dishes)
    else:
        return redirect("/login")
        
@app.route('/create_user_dish', methods=['POST'])
def create_user_dish():
       args = request.args
       dish_id = args.get('dish_id')
       email = session.get('email')
       Dishes.create_user_dish(email, dish_id)
       data = {
              'dish_id': dish_id,
              'status': "success"
       }
       return jsonify(data)

@app.route('/delete_user_dish', methods=['DELETE'])
def delete_user_dish():
       args = request.args
       dish_id = args.get('dish_id')
       email = session.get('email')
       Dishes.delete_user_dish(email, dish_id)
       return redirect('/cart')

@app.route('/update_user_dish', methods=['PUT'])
def update_user_dish():
       args = request.args
       dish_id = args.get('dish_id')
       status = args.get('status')
       email = session.get('email')
       if(status == 'order'):
           status = 'delivered'
       else:
            status = 'pending'
       Dishes.update_user_dish(email, dish_id, status)
       return redirect('/cart')

@app.route('/recommendation_page')
def recommendation_page():
    if session.get('logged_in'):
        return render_template('recommendation_page.html')
    else:
        return redirect("/login")

@app.route('/registration', methods=["GET", "POST"])
def registration_Page():
    if request.method == "POST":
        email = request.form.get('email')
        password = request.form.get('password')
        first_name = request.form.get('fname')
        last_name = request.form.get('lname')

        if len(email) >=1 and len(password) >=1 and len(first_name) >=1 :
            is_user_saved = Auth.register(email, password, first_name, last_name)

            if is_user_saved:
                # Save logged-in user to session
                session['user_name'] = first_name + " " + last_name
                session['email'] = email
                session['logged_in'] = True
                return redirect(url_for('foodworld_homepage'))
            else:
                return render_template('registration.html', msg = "Email already exists")
        else :
            return render_template('registration.html', msg = "Validate all required fields")

    if request.method == "GET":
        # Check if user is logged in
        if session.get('logged_in'):
            return redirect(url_for('foodworld_homepage'))
        return render_template('registration.html')

@app.route('/login', methods=["GET", "POST"])
def login_Page():
    if request.method == "POST":
        email = request.form.get('email')
        password = request.form.get('password')

        if not email or not password:
            return render_template('login.html', msg = "Validate all required fields")

        # Check if user exists in the database
        user = Auth.login(email, password)
        if user:
            # Save logged-in user to session
            session['user_name'] = user[0].first_name + " " + user[0].last_name
            session['email'] = email
            session['logged_in'] = True
            return redirect(url_for('foodworld_homepage'))
        else:
            return render_template('login.html', msg = "Invalid email or password")

    if request.method == "GET":
        # Check if user is logged in
        if session.get('logged_in'):
            return redirect(url_for('foodworld_homepage'))
        return render_template('login.html')

@app.route('/logout')
def logout_Page():
    Auth.logout()
    return redirect("/login")

@app.route('/food_world')
def food_world():
    if session.get('logged_in'):
        return render_template('food_world.html')
    else:
        return redirect("/login")

@app.route('/about_us')
def aboutus_page():
        return render_template('about_us.html')

@app.route('/recpie_page')
def recipe_page(): 
    if session.get('logged_in'):
        print("User Name: " + session.get('user_name'))
        return render_template('recpie_page.html', user_name=session.get('user_name'))
    else:
        return redirect("/login")

@app.route('/policy')
def policy_Page():
    print(session.get("logged_in"))
    if session.get('logged_in'):
        return render_template('policy.html')
    else:
        return redirect("/login")

@app.route('/customer_service')
def customer_service_Page():
    print(session.get("logged_in"))
    if session.get('logged_in'):
        return render_template('customer_service.html')
    else:
        return redirect("/login")

@app.route('/not_found')
def page_not_found():
    return render_template('not_found.html')

def error_page(e):  
  return redirect("/not_found")

app.register_error_handler(500, error_page)
app.register_error_handler(404, error_page)

if __name__ == '__main__':
    app.run(debug=True)

